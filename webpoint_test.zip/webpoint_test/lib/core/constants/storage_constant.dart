class StorageConstant {
  static const String token = "token";
}
