class ApiConstants {
  static const String baseurl = 'https://jsonplaceholder.typicode.com/';
  static const String getPosts = 'posts';
}
